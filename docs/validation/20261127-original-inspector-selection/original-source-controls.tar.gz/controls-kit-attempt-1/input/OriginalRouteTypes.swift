import Foundation
import TorahInspectorCore

public enum TorahInspectorRoute: Hashable, Sendable {
    case search
    case segment(TorahTextSegment)
    case source(TorahInspectorSelection)
    case fullSource(TorahInspectorSelection)
}

public struct TorahStudyToolID: RawRepresentable, Hashable, Identifiable, Sendable {
    public let rawValue: String
    public var id: String { rawValue }

    public init(rawValue: String) { self.rawValue = rawValue }

    public static let commentaries = Self(rawValue: "commentaries")
    public static let links = Self(rawValue: "links")
    public static let notes = Self(rawValue: "notes")
    public static let relatedDocuments = Self(rawValue: "relatedDocuments")

    public func localizedTitle(locale: Locale) -> String {
        switch self {
        case .commentaries: TorahStrings.text("Commentaries", locale: locale)
        case .links: TorahStrings.text("Links", locale: locale)
        case .notes: TorahStrings.text("Notes", locale: locale)
        case .relatedDocuments: TorahStrings.text("In Documents", locale: locale)
        default: rawValue
        }
    }
}

public enum TorahStudyTool: String, CaseIterable, Identifiable, Hashable, Sendable {
    case commentaries
    case links
    case notes

    public var id: Self { self }
    public var toolID: TorahStudyToolID { TorahStudyToolID(rawValue: rawValue) }

    public var localizedTitle: String {
        switch self {
        case .commentaries: TorahStrings.text("Commentaries")
        case .links: TorahStrings.text("Links")
        case .notes: TorahStrings.text("Notes")
        }
    }

    public func localizedTitle(locale: Locale) -> String {
        switch self {
        case .commentaries: TorahStrings.text("Commentaries", locale: locale)
        case .links: TorahStrings.text("Links", locale: locale)
        case .notes: TorahStrings.text("Notes", locale: locale)
        }
    }
}
