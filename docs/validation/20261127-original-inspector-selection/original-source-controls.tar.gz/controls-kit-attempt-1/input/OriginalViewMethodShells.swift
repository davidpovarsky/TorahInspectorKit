import Foundation
import TorahInspectorCore

@MainActor struct RootShell {
    let navigationLifetime = TorahInspectorNavigationLifetime()
    let external = ControlState<TorahStudyToolID>(wrappedValue: .commentaries)
    @ControlState var localSelectedToolID: TorahStudyToolID = .commentaries
    var externalSelectedToolID: Binding<TorahStudyToolID>? {
        Binding(get: { external.wrappedValue }, set: { external.wrappedValue = $0 })
    }
    var externalSelectedTool: Binding<TorahStudyTool>? { nil }
    func controlBinding() -> Binding<TorahStudyToolID> { selectedToolBinding }
private var selectedToolBinding: Binding<TorahStudyToolID> {
        Binding(
            get: {
                externalSelectedToolID?.wrappedValue
                    ?? externalSelectedTool?.wrappedValue.toolID
                    ?? localSelectedToolID
            },
            set: { newValue in
                navigationLifetime.toolWillChange()
                if let externalSelectedToolID {
                    externalSelectedToolID.wrappedValue = newValue
                } else if let externalSelectedTool,
                          let legacy = TorahStudyTool(rawValue: newValue.rawValue) {
                    externalSelectedTool.wrappedValue = legacy
                } else {
                    localSelectedToolID = newValue
                }
            }
        )
    }
}
@MainActor struct PathShell {
    let navigationLifetime: TorahInspectorNavigationLifetime?
    @ControlState var path: [TorahInspectorRoute] = []
    init(lifetime: TorahInspectorNavigationLifetime) { navigationLifetime = lifetime }
    var current: [TorahInspectorRoute] { path }
    func change(_ value: [TorahInspectorRoute]) { originalNavigationPath.wrappedValue = value }
private var originalNavigationPath: Binding<[TorahInspectorRoute]> {
        Binding(get: { path }, set: { value in
            navigationLifetime?.identityWillChange()
            path = value
        })
    }
}
@MainActor struct DetailShell {
    let focus: TorahInspectorFocus
    let repository = TorahInspectorRepository(textFetcher: { _, _ in throw ControlFailure(message: "unused original text fetch") })
    let navigationLifetime = TorahInspectorNavigationLifetime()
    let originalToolBinding: Binding<TorahStudyToolID>
    let locale = Locale(identifier: "en")
    @ControlState var configuration = TorahInspectorConfiguration()
    @ControlState var linksState = TorahPanelLoadState<TorahLinksSnapshot>.idle
    @ControlState var topicsState = TorahPanelLoadState<[TorahLinkedTopic]>.idle
    @ControlState var notesState = TorahPanelLoadState<[TorahInspectorNote]>.idle
    @ControlState var loadedFocusID: String? = nil
    @ControlState var expandedCommentaryGroupIDs = Set<String>()
    @ControlState var expandedSourceIDs = Set<String>()
    var selectedTool: TorahStudyToolID {
        get { originalToolBinding.wrappedValue }
        nonmutating set { originalToolBinding.wrappedValue = newValue }
    }
    init(focus: TorahInspectorFocus, selectedTool: Binding<TorahStudyToolID>) {
        self.focus = focus; originalToolBinding = selectedTool
    }
    // Explicit localization-only boundary; the actual values/IDs and catalog
    // selection branch below are retained from the original view.
    func commentaryGroupTitle(_ group: TorahSourceGroup) -> String { group.title }
    func displayReference(_ source: TorahLinkedSource) -> String { source.sourceRef }
    var expanded: Set<String> { expandedCommentaryGroupIDs }
    func controlConfigure(_ tools: [TorahStudyToolID]) { configuration.availableTools = tools }
    func controlExpand(_ id: String, _ value: Bool) { originalGroupExpansion(id).wrappedValue = value }
    func controlPanel(scope: TorahInspectorNavigationScope, scroll: ScrollViewProxy) -> TorahInspectorOriginalPanel {
        originalNavigationPanel(scope: scope, scroll: scroll)
    }
    func controlLoad(links: [TorahLinkedSource], notes: [TorahInspectorNote]) {
        loadedFocusID = focus.id
        controlReloadLinks(links)
        navigationLifetime.contentWillChange()
        let request = topicsState.begin(focusID: focus.id)
        originalContentWillPublish(topicsState, request: request)
        topicsState.publish([], for: request)
        controlPendingNotes(); controlCompleteNotes(notes)
    }
    func controlReloadLinks(_ links: [TorahLinkedSource]) {
        navigationLifetime.contentWillChange()
        let request = linksState.begin(focusID: focus.id)
        let snapshot = TorahLinksSnapshot(sources: links, groups: TorahRelationshipGroups(sources: links))
        originalContentWillPublish(linksState, request: request)
        linksState.publish(snapshot, for: request)
    }
    func controlPendingNotes() {
        navigationLifetime.contentWillChange()
        _ = notesState.begin(focusID: focus.id)
    }
    func controlCompleteNotes(_ notes: [TorahInspectorNote]) {
        if case .loading = notesState {} else { controlPendingNotes() }
        guard case .loading(let request, _) = notesState else { fatalError("fixture load must exist") }
        originalContentWillPublish(notesState, request: request)
        notesState.publish(notes, for: request)
    }
private var groups: TorahRelationshipGroups {
        linksState.value?.groups ?? TorahRelationshipGroups(sources: [])
    }

private var notes: [TorahInspectorNote] { notesState.value ?? [] }

private func originalGroupExpansion(_ id: String) -> Binding<Bool> {
        Binding(get: { expandedCommentaryGroupIDs.contains(id) }, set: { isExpanded in
            navigationLifetime.expansionWillChange()
            if isExpanded {
                expandedCommentaryGroupIDs.insert(id)
            } else {
                expandedCommentaryGroupIDs.remove(id)
            }
        })
    }

private func originalContentWillPublish<Value: Sendable>(_ state: TorahPanelLoadState<Value>,
                                                  request: TorahPanelRequest) {
        guard case .loading(let current, _) = state, current == request else { return }
        navigationLifetime.contentWillChange()
    }

private var originalNavigationState: TorahInspectorNavigationPanelState {
        var ready = Set<TorahStudyToolID>()
        if loadedFocusID == focus.id {
            if case .loaded = linksState {
                ready.insert(.commentaries)
                if case .loaded = topicsState { ready.insert(.links) }
            }
            if case .loaded = notesState { ready.insert(.notes) }
        }
        let finite: [TorahStudyToolID] = [.commentaries, .links, .notes]
        var targets = finite.filter { configuration.availableTools.contains($0) }.map {
            TorahInspectorNavigationTarget(anchor: .tool($0),
                title: $0.localizedTitle(locale: locale), tool: $0)
        }
        if selectedTool == .commentaries, ready.contains(.commentaries) {
            for (items, quoting) in [(groups.commentaryGroups, false), (groups.quotingCommentaryGroups, true)] {
                for group in items {
                    targets.append(TorahInspectorNavigationTarget(
                        anchor: .commentaryGroup(id: group.id, quoting: quoting),
                        title: commentaryGroupTitle(group), tool: .commentaries, group: group))
                    // Follow the original renderer's work/entry branch exactly.
                    let entries = group.works.count > 1 ? group.works.flatMap(\.entries) : group.entries
                    for source in entries {
                        targets.append(TorahInspectorNavigationTarget(
                            anchor: .source(id: source.id, groupID: group.id, quoting: quoting),
                            title: displayReference(source), tool: .commentaries, group: group, source: source))
                    }
                }
            }
        } else if selectedTool == .links, ready.contains(.links) {
            for source in groups.linkedSources {
                targets.append(TorahInspectorNavigationTarget(
                    anchor: .source(id: source.id, groupID: nil, quoting: false),
                    title: displayReference(source), tool: .links, source: source))
            }
        } else if selectedTool == .notes, ready.contains(.notes) {
            for note in notes {
                targets.append(TorahInspectorNavigationTarget(anchor: .note(id: note.id),
                    title: note.note, tool: .notes, note: note))
            }
        }
        return TorahInspectorNavigationPanelState(selectedTool: selectedTool,
            readyTools: ready, targets: targets, expandedGroupIDs: expandedCommentaryGroupIDs,
            expandedSourceIDs: expandedSourceIDs)
    }

private func originalNavigationPanel(scope: TorahInspectorNavigationScope,
                                         scroll: ScrollViewProxy) -> TorahInspectorOriginalPanel {
        TorahInspectorOriginalPanel(lifetime: navigationLifetime, scope: scope,
            focus: focus, repository: repository, read: { originalNavigationState },
            selectTool: { selectedTool = $0 },
            expandGroup: { originalGroupExpansion($0).wrappedValue = true },
            scroll: { scroll.scrollTo($0, anchor: .top) })
    }

}
